# Module initialization file
# Makes the pages directory a Python package